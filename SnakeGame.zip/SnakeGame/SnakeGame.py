import pygame
import random

pygame.init()

# Game window details
gridsize = (20, 20)
cellsize = 20
windowsize = (gridsize[0] * cellsize, gridsize[1] * cellsize)
fps = 10
backgroundimage = "backgroundimage.png"

# Colours
white = (237, 234, 245)
green = (28, 98, 27)
red = (181, 27, 27)
blue = (15, 28, 102)
black = (0, 0, 0)

# Directions
up = (0, -1)
down = (0, 1)
left = (-1, 0)
right = (1, 0)

# Initialize game window
screen = pygame.display.set_mode(windowsize)
pygame.display.set_caption("Shaan's Snake Game")

backgroundimage = pygame.image.load(backgroundimage)
backgroundimage = pygame.transform.scale(backgroundimage, windowsize)

class Snake:
    def __init__(self, initialpositions, color):
        self.positions = initialpositions
        self.direction = right
        self.color = color
        
    def changedirection(self, newdirection):
        if (self.direction[0] + newdirection[0], self.direction[1] + newdirection[1]) != (0, 0):
            self.direction = newdirection
    
    def move(self):
        snakehead = (self.positions[0][0] + self.direction[0], self.positions[0][1] +  self.direction[1])

        if (snakehead[0] < 0 or snakehead [0] >= gridsize[0] or
            snakehead[1] < 0 or snakehead[1] >= gridsize[1] or
            snakehead in self.positions):
            return False
        
        self.positions.insert(0, snakehead)
        return True
    
    def grow(self):
        # The grow method can be implemented by not removing the last segment
        pass

    def shrink(self):
        self.positions.pop()

def placefood(snake1, snake2=None):
    while True:
        position = (random.randint(0, gridsize[0] - 1), random.randint(0, gridsize[1] - 1))
        if position not in snake1.positions and (snake2 is None or position not in snake2.positions):
            return position

def drawsnake(screen, snake):
    for segment in snake.positions:
        pygame.draw.rect(screen, snake.color, pygame.Rect(segment[0] * cellsize, segment[1] * cellsize, cellsize, cellsize))

def draw_text(screen, text, size, color, x, y):
    font = pygame.font.Font(None, size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    screen.blit(text_surface, text_rect)

def main(single_player=False):
    clock = pygame.time.Clock()

    snake1 = Snake([(10, 10), (10, 9), (10, 8)], green)
    snake2 = Snake([(15, 15), (15, 14), (15, 13)], blue) if not single_player else None

    food_position = placefood(snake1, snake2)
    score1 = 0
    score2 = 0 if not single_player else None

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return "quit"
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            snake1.changedirection(up)
        if keys[pygame.K_s]:
            snake1.changedirection(down)
        if keys[pygame.K_a]:
            snake1.changedirection(left)
        if keys[pygame.K_d]:
            snake1.changedirection(right)
        
        if not single_player:
            if keys[pygame.K_UP]:
                snake2.changedirection(up)
            if keys[pygame.K_DOWN]:
                snake2.changedirection(down)
            if keys[pygame.K_LEFT]:
                snake2.changedirection(left)
            if keys[pygame.K_RIGHT]:
                snake2.changedirection(right)

        if not (snake1.move() and (single_player or snake2.move())):
            running = False
        
        if snake1.positions[0] == food_position:
            snake1.grow()
            score1 += 1
            food_position = placefood(snake1, snake2)
        else:
            snake1.shrink()
        
        if not single_player and snake2.positions[0] == food_position:
            snake2.grow()
            score2 += 1
            food_position = placefood(snake1, snake2)
        elif not single_player:
            snake2.shrink()
        
        screen.blit(backgroundimage, (0, 0))
        drawsnake(screen, snake1)
        if not single_player:
            drawsnake(screen, snake2)
        pygame.draw.rect(screen, red, pygame.Rect(food_position[0] * cellsize, food_position[1] * cellsize, cellsize, cellsize))

        draw_text(screen, f"Score 1: {score1}", 30, black, windowsize[0] / 10, 10)
        if not single_player:
            draw_text(screen, f"Score 2: {score2}", 30, black, windowsize[0] - windowsize[0] / 10, 10)
        
        pygame.display.flip()
        clock.tick(fps)
    
    return "game_over", score1, score2 if not single_player else score1

def game_over_screen(score1, score2=None):
    game_over_running = True
    while game_over_running:
        screen.fill(white)
        draw_text(screen, "Game Over!", 50, red, windowsize[0] / 2, windowsize[1] / 4)
        draw_text(screen, f"Player 1 Score: {score1}", 35, black, windowsize[0] / 2, windowsize[1] / 2)
        if score2 is not None:
            draw_text(screen, f"Player 2 Score: {score2}", 35, black, windowsize[0] / 2, windowsize[1] / 2 + 40)
        draw_text(screen, "Press R to Restart or Q to Quit", 30, blue, windowsize[0] / 2, windowsize[1] / 2 + 80)
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    game_over_running = False
                    return "restart"
                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()

def menu():
    menu_running = True
    while menu_running:
        screen.fill(white)
        draw_text(screen, "Shaan's Snake Game", 50, green, windowsize[0] / 2, windowsize[1] / 4)
        draw_text(screen, "Press P to Play", 35, blue, windowsize[0] / 2, windowsize[1] / 2)
        draw_text(screen, "Press S for Single Player", 35, blue, windowsize[0] / 2, windowsize[1] / 2 + 40)
        draw_text(screen, "Press M for Multiplayer", 35, blue, windowsize[0] / 2, windowsize[1] / 2 + 80)
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    menu_running = False
                    result = main()
                elif event.key == pygame.K_s:
                    menu_running = False
                    result = main(single_player=True)
                elif event.key == pygame.K_m:
                    menu_running = False
                    result = main()
                
                if result == "quit":
                    pygame.quit()
                    quit()
                elif result[0] == "game_over":
                    restart = game_over_screen(result[1], result[2] if not isinstance(result[2], int) else None)
                    if restart == "restart":
                        menu()

if __name__ == "__main__":
    menu()
